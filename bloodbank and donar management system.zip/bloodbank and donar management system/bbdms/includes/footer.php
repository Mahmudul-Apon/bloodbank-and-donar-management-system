<style>
	.footer-copyright{
		color: #FFFFFF;
	}
	.py-5{
		background-color: #006973;
		padding-top: 0rem!important; 
  		padding-bottom: 1rem!important;
	}

</style>



  <footer class="py-5">
   	
        <div class="footer-copyright text-center py-4">
        	<a style="color: #FFFFFF">© 2020 Copyright:</a>
    		<a href="#" style="color: #ddd;"> BloodBank & Donor Management System</a>
  		</div>
       
    </footer>



  