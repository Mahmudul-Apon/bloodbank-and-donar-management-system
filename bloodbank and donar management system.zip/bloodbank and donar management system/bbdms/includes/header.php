<style>
    .navbar-brand{
         font-family: cursive;
    }
    
</style>

    <nav class="navbar fixed-top navbar-toggleable-md navbar-inverse bg-inverse">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarExample" aria-controls="navbarExample" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="container">
            <a class="navbar-brand" href="index.php">BloodBank & Donor Management System</a>
            <div class="collapse navbar-collapse" id="navbarExample" >
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="page.php?type=aboutus">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="page.php?type=donor" style="background: url(/img-thing.jpeg) no-repeat top left;">Why Become Donor</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="become-donar.php">Become a Donar</a>
                    </li>
                 
                     <li class="nav-item">
                        <a class="nav-link" href="search-donor.php">Search Blood</a>
                    </li>
                      <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact us</a>
                    </li>
                   <!--  <li class="nav-item">
                        <a class="nav-link" href="donor-login.php">Login</a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" href="contact.php">/ Register</a>
                    </li> -->
                 
                </ul>
            </div>
        </div>
    </nav>


