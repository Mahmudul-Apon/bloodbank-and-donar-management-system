<?php
error_reporting(0);
include('includes/config.php');
include 'actionl.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BloodBank & Donor Management System | Become A Donar</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/modern-business.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <!-- Popper JS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <!-- Latest compiled JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.18/datatables.min.css" />

  <script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.18/datatables.min.js"></script>
    <style>
    .navbar-toggler {
        z-index: 1;
    }
    
    @media (max-width: 576px) {
        nav > .container {
            width: 100%;
        }
    }
    </style>
        <style>
    .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.btn {
        border: none;
    font-size: 14px;
    line-height: 22px;
    font-weight: 500;
    text-transform: uppercase;
    padding: 6px 45px;
}

.page-title {
    padding-bottom: 15px;
    margin-bottom: 2px;
    border-bottom: 1px solid #f0f0f0;
}
p.p-1.m-0.font-ubuntu.text-black-50 {
    margin-bottom: 5px;
}
.panel {
    margin-top: 5px;
}

.panel-default .panel-heading, .panel-default .panel-title, .panel-default .panel-footer {
    text-align: left;
}

form.form-horizontal {
    padding: 40px 0px;
}


  h4.text {
    font-size: 15px;
    border-bottom: 1px solid #282923;
}

h2.bg-light.p-2.rounded.text-center{
    margin-bottom: 35px;
    border-bottom: 1px solid #ddd;
    padding-bottom: 20px;
}
.col-md-6.mt-3.bg-info.p-4.rounded {
    margin-left: 190px;

}
    </style>


</head>

<body>

<?php include('includes/header.php');?>

    <!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <h1 class="mt-4 mb-3">Search <small>Donor</small></h1>

        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active">Search  Donor</li>
        </ol>
            <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
        else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
        <!-- Content Row -->


    <div class="content-wrapper">
      <div class="container-fluid">
               <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6 mt-3 bg-info p-4 rounded">
        <h2 class="bg-light p-2 rounded text-center">Profile : <?= $vfullname; ?></h2>
       <!--  <div class="text-center">
          <img src="<?= $vphoto; ?>" width="300" class="img-thumbnail">
        </div> -->
        <h4 class="text">Name : <?= $vfullname; ?></h4>
        <h4 class="text">Mobile No : <?= $vmobileno; ?></h4>
        <h4 class="text">Email : <?= $vemailid; ?></h4>
        <h4 class="text">Password : <?= $vpassword; ?></h4>
        <h4 class="text">Age : <?= $vage; ?></h4>
        <h4 class="text">Gender : <?= $vgender; ?></h4>
        <h4 class="text">Blood-Group : <?= $vbloodgroup; ?></h4>
        <h4 class="text">Smoker : <?= $vsmoker; ?></h4>
        <h4 class="text">Drug : <?= $vdrug; ?></h4>
        <h4 class="text">Last Donation Date : <?= $vldate; ?></h4>
        <h4 class="text">Weight : <?= $vweight; ?></h4>
        <h4 class="text">Date of Birth : <?= $vbirth; ?></h4>
        <h4 class="text">Living District : <?= $vdistrict; ?></h4>
        <h4 class="text">Present Address : <?= $vaddress; ?></h4>
        <h4 class="text">Message : <?= $vmessage; ?></h4>
      </div>
    </div>

    </div>
        
    </div>
  </div>
















  <?php include('includes/footer.php');?>
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/tether/tether.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

</body>

</html>
