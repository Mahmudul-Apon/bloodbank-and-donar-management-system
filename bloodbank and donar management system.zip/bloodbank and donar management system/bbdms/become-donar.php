<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
   
if (isset($_POST['submit'])) {
    $fullname = $_POST['fullname'];
    $mobileno = $_POST['mobileno'];
    $emailid = $_POST['emailid'];
    $password = $_POST['password'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $bloodgroup = $_POST['bloodgroup'];
    $smoker = $_POST['smoker'];
    $drug = $_POST['drug'];
    $ldate = $_POST['ldate'];
    $weight = $_POST['weight'];
    $birth = $_POST['birth'];
    $district = $_POST['district'];
    $address = $_POST['address'];
    $message = $_POST['message'];
    $donation = $_POST['donation'];
    $status = 1;


$sql="INSERT INTO  tbregister(fullname,mobileno,emailid,password,age,gender,bloodgroup,smoker,drug,        ldate,weight,birth,district,address,message,donation,status) VALUES ('$fullname','$mobileno','$emailid','$password','$age','$gender','$bloodgroup','$smoker','$drug','$ldate','$weight','$birth','$district','$address','$message','$donation', '$status')";


$query = $dbh->prepare($sql);
$query->bindParam(':fullname',$fullname,PDO::PARAM_STR);
$query->bindParam(':mobileno',$mobileno,PDO::PARAM_STR);
$query->bindParam(':emailid',$emailid,PDO::PARAM_STR);
$query->bindParam(':password',$password,PDO::PARAM_STR);
$query->bindParam(':donation',$donation,PDO::PARAM_STR);
$query->bindParam(':age',$age,PDO::PARAM_STR);
$query->bindParam(':gender',$gender,PDO::PARAM_STR);
$query->bindParam(':bloodgroup',$bloodgroup,PDO::PARAM_STR);
$query->bindParam(':smoker',$smoker,PDO::PARAM_STR);
$query->bindParam(':drug',$drug,PDO::PARAM_STR);
$query->bindParam(':ldate',$ldate,PDO::PARAM_STR);
$query->bindParam(':weight',$weight,PDO::PARAM_STR);
$query->bindParam(':birth',$birth,PDO::PARAM_STR);
$query->bindParam(':district',$district,PDO::PARAM_STR);
$query->bindParam(':message',$message,PDO::PARAM_STR);
$query->bindParam(':status',$status,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$msg=" Your info submitted successfully";
}
else 
{
$error="Something went wrong. Please try again";
}

}


    ?>


<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BloodBank & Donor Management System | Become A Donar</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/modern-business.css" rel="stylesheet">
    <style>
    .navbar-toggler {
        z-index: 1;
    }
    
    @media (max-width: 576px) {
        nav > .container {
            width: 100%;
        }
    }
    </style>
        <style>
    .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
/*.breadcrumb {
    background-color: darkcyan;
}
.breadcrumb-item.active {
    color: #FFFFFF;
}
*/
    </style>

<script language="javascript">
function isNumberKey(evt)
      {
         
        var charCode = (evt.which) ? evt.which : event.keyCode
                
        if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode!=46)
           return false;

         return true;
      }
      </script>
</head>

<body>

<?php include('includes/header.php');?>

    <!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <h1 class="mt-4 mb-3">Become a <small>Donor</small></h1>

        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active">Become a Donor</li>
        </ol>
            <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
        else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
        <!-- Content Row -->
<form name="donar" method="POST" action="">
<div class="row">
<div class="col-lg-4 mb-4">
<div class="font-italic">Full Name<span style="color:red">*</span></div>
<div><input type="text" name="fullname" class="form-control" required></div>
</div>
<div class="col-lg-4 mb-4">
<div class="font-italic">Mobile Number<span style="color:red">*</span></div>
<div><input type="text" name="mobileno" class="form-control" required></div>
</div>
<div class="col-lg-4 mb-4">
<div class="font-italic">Email Id</div>
<div><input type="email" name="emailid" class="form-control"></div>
</div>
</div>

<!-- ####################################################### -->

<div class="row">
<div class="col-lg-4 mb-4">
<div class="font-italic">Password<span style="color:red">*</span></div>
<div><input type="password" name="password" class="form-control" required></div>
</div>
<div class="col-lg-4 mb-4">
<div class="font-italic">How many times donation ?<span style="color:red">*</span></div>
<select name="donation" class="form-control" required>
<option>Select</option>
<option>Not once</option>
<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option>6</option>
<option>7</option>
<option>8</option>
<option>9</option>
<option>10</option>
</select>
</div>

<div class="col-lg-4 mb-4">
<div class="font-italic">Smoker?</div>
<select name="smoker" class="form-control" required>
<option>Select</option>
<option>No</option>
<option>Yes</option>
</select>
</div>
</div>

<!-- ####################################################### -->

<div class="row">
<div class="col-lg-4 mb-4">
<div class="font-italic">Age<span style="color:red">*</span></div>
<div><input type="text" name="age" class="form-control" required></div>
</div>


<div class="col-lg-4 mb-4">
<div class="font-italic">Gender<span style="color:red">*</span></div>
<div><select name="gender" class="form-control" required>
<option value="">Select</option>
<option value="Male">Male</option>
<option value="Female">Female</option>
<option value="Others">Others</option>
</select>
</div>
</div>

<div class="col-lg-4 mb-4">
<div class="font-italic">Blood Group<span style="color:red">*</span> </div>
<div><select name="bloodgroup" class="form-control" required>
<?php $sql = "SELECT * from  tblbloodgroup ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{               ?>  
<option value="<?php echo htmlentities($result->BloodGroup);?>"><?php echo htmlentities($result->BloodGroup);?></option>
<?php }} ?>
</select>
</div>
</div>
</div>

<!--2 ############################ -->


<div class="row">
<div class="col-lg-4 mb-4">
<div class="font-italic">Drug Accidted?<span style="color:red">*</span></div>
<select name="drug" class="form-control" required>
<option>Select</option>
<option>No</option>
<option>Yes</option>
</select>
</div>

<div class="col-lg-4 mb-4">
<div class="font-italic">Last Donation Date<span style="color:red">*</span></div>
<div><input type="date" name="ldate" class="form-control" required></div>
</div>

<div class="col-lg-4 mb-4">
<div class="font-italic">Weight</div>
<div><input type="text" name="weight" class="form-control"></div>
</div>
</div>

<div class="row">
<div class="col-lg-4 mb-4">
<div class="font-italic">Date of Birth<span style="color:red">*</span></div>
<div><input type="date" name="birth" class="form-control" required></div>
</div>

<div class="col-lg-4 mb-4">
<div class="font-italic">Living District<span style="color:red">*</span></div>
<select name="district" class="form-control" required>
<option>Select one...</option><option>Bagerhat</option>
<option>Bandarban</option>
<option>Barguna</option>
<option>Barisal</option>
<option>Bhola</option>
<option>Bogra</option>
<option>Brahmanbaria</option>
<option>Chandpur</option>
<option>Chittagong</option>
<option>Chuadanga</option>
<option>Comilla</option>
<option>Cox's Bazar</option>
<option>Dhaka</option>
<option>Dinajpur</option>
<option>Faridpur</option>
<option>Feni</option>
<option>Gaibandha</option>
<option>Gazipur</option>
<option>Gopalganj</option>
<option>Habiganj</option>
<option>Jaipurhat</option>
<option>Jamalpur</option>
<option>Jessore</option>
<option>Jhalokati</option>
<option>Jhenaidah</option>
<option>Khagrachari</option>
<option>Khulna</option>
<option>Kishoreganj</option>
<option>Kurigram</option>
<option>Kushtia</option>
<option>Lakshmipur</option>
<option>Lalmonirhat</option>
<option>Madaripur</option>
<option>Magura</option>
<option>Manikgonj</option>
<option>Maulvi Bazar</option>
<option>Meherpur</option>
<option>Munshiganj</option>
<option>Mymensingh</option>
<option>Naogaon</option>
<option>Narail</option>
<option>Narayanganj</option>
<option>Narsingdi</option>
<option>Natore</option>
<option>Nawabganj</option>
<option>Netrokona</option>
<option>Nilphamari</option>
<option>Noakhali</option>
<option>Pabna</option>
<option>Panchagarh</option>
<option>Patuakhali</option>
<option>Pirojpur</option>
<option>Rajbari</option>
<option>Rajshahi</option>
<option>Rangamati</option>
<option>Rangpur</option>
<option>Shariatpur</option>
<option>Shatkhira</option>
<option>Sherpur</option>
<option>Sirajganj</option>
<option>Sunamgonj</option>
<option>Sylhet</option>
<option>Tangail</option>
<option>Thakurgaon</option>
</select>
</div>


</div>




<!-- ############################ -->

<div class="row">
<div class="col-lg-4 mb-4">
<div class="font-italic">Present Address</div>
<div><textarea class="form-control" name="address"></textarea></div>
</div>

<div class="col-lg-8 mb-4">
<div class="font-italic">Message<span style="color:red">*</span></div>
<div><textarea class="form-control" name="message" required> </textarea></div>
</div>
</div>

<div class="row" style="margin-bottom: 50px">
<div class="col-sm-12 col-sm-offset-2 text-center">
<button class="btn btn-default" type="reset" style="cursor: pointer;">Clear</button>
<button class="btn btn-primary" name="submit" type="submit" style="cursor: pointer;">Submit</button>
</div>



</div>



        <!-- /.row -->
</form>   
        <!-- /.row -->
</div>
  <?php include('includes/footer.php');?>
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/tether/tether.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

</body>

</html>
