<?php 

$connection = mysqli_connect("localhost", "root", "");
$db = mysqli_select_db($connection, 'bbdms');

if (isset($_POST['submit'])) {
	$fullname = $_POST['fullname'];
	$mobileno = $_POST['mobileno'];
	$emailid = $_POST['emailid'];
	$password = $_POST['password'];
	$age = $_POST['age'];
	$gender = $_POST['gender'];
	$bloodgroup = $_POST['bloodgroup'];
	$smoker = $_POST['smoker'];
	$drug = $_POST['drug'];
	$ldate = $_POST['ldate'];
	$weight = $_POST['weight'];
	$birth = $_POST['birth'];
	$district = $_POST['district'];
	$address = $_POST['address'];
	$message = $_POST['message'];
	$donation = $_POST['donation'];
	$status = 1;

	$query="INSERT INTO  tbregister(fullname,mobileno,emailid,password,age,gender,bloodgroup,smoker,drug,        ldate,weight,birth,district,address,message,donation,status) VALUES ('$fullname','$mobileno','$emailid','$password','$age','$gender','$bloodgroup','$smoker','$drug','$ldate','$weight','$birth','$district','$address','$message','$donation', '$status')";
	$query_run = mysqli_query($connection, $query);

	if ($query_run) 
	{
		echo '<script> alart("Data Save"); </script>';
		header('location: doner-registration.php');
	}
	else
	{
		echo '<script> alart("Data Not Save"); </script>';
		// echo "registration not successful";
	}
}



 ?>