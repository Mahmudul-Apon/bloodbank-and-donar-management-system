
<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
  { 
header('location:index.php');
}
else{
if(isset($_REQUEST['hidden']))
  {
$eid=intval($_GET['hidden']);
$status="0";
$sql = "UPDATE tbregister SET Status=:status WHERE  id=:eid";
$query = $dbh->prepare($sql);
$query -> bindParam(':status',$status, PDO::PARAM_STR);
$query-> bindParam(':eid',$eid, PDO::PARAM_STR);
$query -> execute();

$msg="Booking Successfully Cancelled";
}


if(isset($_REQUEST['public']))
  {
$aeid=intval($_GET['public']);
$status=1;

$sql = "UPDATE tbregister SET Status=:status WHERE  id=:aeid";
$query = $dbh->prepare($sql);
$query -> bindParam(':status',$status, PDO::PARAM_STR);
$query-> bindParam(':aeid',$aeid, PDO::PARAM_STR);
$query -> execute();

$msg="Booking Successfully Confirmed";
}
if(isset($_REQUEST['del']))
  {
$did=intval($_GET['del']);
$sql = "delete from tbregister WHERE  id=:did";
$query = $dbh->prepare($sql);
$query-> bindParam(':did',$did, PDO::PARAM_STR);
$query -> execute();

$msg="Record deleted Successfully ";
}

 ?>

<!doctype html>
<html lang="en" class="no-js">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <meta name="theme-color" content="#3e454c">
  
  <title>BBDMS | Donors Profile  </title>

  <!-- Font awesome -->
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <!-- Sandstone Bootstrap CSS -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- Bootstrap Datatables -->
  <link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
  <!-- Bootstrap social button library -->
  <link rel="stylesheet" href="css/bootstrap-social.css">
  <!-- Bootstrap select -->
  <link rel="stylesheet" href="css/bootstrap-select.css">
  <!-- Bootstrap file input -->
  <link rel="stylesheet" href="css/fileinput.min.css">
  <!-- Awesome Bootstrap checkbox -->
  <link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
  <!-- Admin Stye -->
  <link rel="stylesheet" href="css/style.css">
  <style>
    .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}

.make:hover{
  text-decoration: none;
    color: #FFFFFF;
    background-color: #218838;
    padding: 5px;
    border-radius: 3px;
}
.make1:hover{
  text-decoration: none;
    color: #FFFFFF;
    background-color: #C82333;
    padding: 5px;
    border-radius: 3px;
}

thead.thead-dark {
    background: #3E444A;
    color: #FFFFFF;
}
th.sorting {
    font-size: revert;
    font-family: monospace;
}

button.btn.btn-success {
    padding: 0px 8px;
}

button.btn.btn-warning {
    padding: 0px 8px;
}


    </style>

</head>

<body>
  <!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#editbtn">
  EDIT
</button>

<!-- Modal -->
<div class="modal fade" id="editbtn" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="donor-registration-code.php" method="POST" class="form-horizontal" enctype="multipart/form-data">
<div class="form-group">
<label class="col-sm-2 control-label">Full Name<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="fullname" class="form-control" value="<?php echo $fullname;?>" required>
</div>
<label class="col-sm-2 control-label">Mobile No<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="mobileno" onKeyPress="return isNumberKey(event)"  maxlength="10" class="form-control" value="<?php echo $mobileno;?>" required>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Email id </label>
<div class="col-sm-4">
<input type="email" name="emailid" class="form-control" value="<?php echo $emailid;?>">
</div>
<label class="col-sm-2 control-label">Age<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="age" class="form-control" value="<?php echo $age;?>" required>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Password </label>
<div class="col-sm-4">
<input type="password" name="password" class="form-control" value="<?php echo $password;?>">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Gender <span style="color:red">*</span></label>
<div class="col-sm-4">
<select name="gender" class="form-control" value="<?php echo $gender;?>" required>
<option value="">Select</option>
<option value="Male">Male</option>
<option value="Female">Female</option>
<option value="Female">Others</option>
</select>
</div>
<label class="col-sm-2 control-label">Blood Group<span style="color:red">*</span></label>
<div class="col-sm-4">


<select name="bloodgroup" class="form-control" value="<?php echo $bloodgroup;?>" required>
<option value="">Select</option>
<?php $sql = "SELECT * from  tblbloodgroup ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{       ?>  
<option value="<?php echo htmlentities($result->BloodGroup);?>"><?php echo htmlentities($result->BloodGroup);?></option>
<?php }} ?>
</select>

</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Smoker? <span style="color:red">*</span></label>
<div class="col-sm-4">
<select name="smoker" class="form-control" value="<?php echo $smoker;?>" required>
<option value="">Select</option>
<option value="Male">No</option>
<option value="Female">Yes</option>
</select>
</div>

<label class="col-sm-2 control-label">Drug Accidted? <span style="color:red">*</span></label>
<div class="col-sm-4">
<select name="drug" class="form-control" value="<?php echo $drug;?>" required>
<option value="">Select</option>
<option value="Male">No</option>
<option value="Female">Yes</option>
</select>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Last Donation Date </label>
<div class="col-sm-4">
<input type="date" name="ldate" class="form-control" value="<?php echo $ldate;?>" >
</div>

<label class="col-sm-2 control-label">Weight<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="weight" class="form-control" value="<?php echo $weight;?>" required>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Date of Birth </label>
<div class="col-sm-4">
<input type="date" name="birth" class="form-control" value="<?php echo $birth;?>">
</div>

<label class="col-sm-2 control-label">Living District <span style="color:red">*</span></label>
<div class="col-sm-4">
<select name="district" class="form-control" value="<?php echo $district;?>" required>
<option value="0">Select one...</option><option value=32 >Bagerhat</option>
<option value=40 >Bandarban</option>
<option value=50 >Barguna</option>
<option value=5 >Barisal</option>
<option value=51 >Bhola</option>
<option value=24 >Bogra</option>
<option value=48 >Brahmanbaria</option>
<option value=49 >Chandpur</option>
<option value=4 >Chittagong</option>
<option value=37 >Chuadanga</option>
<option value=47 >Comilla</option>
<option value=43 >Cox's Bazar</option>
<option value=1 >Dhaka</option>
<option value=58 >Dinajpur</option>
<option value=23 >Faridpur</option>
<option value=44 >Feni</option>
<option value=59 >Gaibandha</option>
<option value=9 >Gazipur</option>
<option value=16 >Gopalganj</option>
<option value=56 >Habiganj</option>
<option value=25 >Jaipurhat</option>
<option value=14 >Jamalpur</option>
<option value=33 >Jessore</option>
<option value=52 >Jhalokati</option>
<option value=36 >Jhenaidah</option>
<option value=42 >Khagrachari</option>
<option value=3 >Khulna</option>
<option value=18 >Kishoreganj</option>
<option value=60 >Kurigram</option>
<option value=38 >Kushtia</option>
<option value=46 >Lakshmipur</option>
<option value=61 >Lalmonirhat</option>
<option value=13 >Madaripur</option>
<option value=35 >Magura</option>
<option value=8 >Manikgonj</option>
<option value=55 >Maulvi Bazar</option>
<option value=39 >Meherpur</option>
<option value=15 >Munshiganj</option>
<option value=10 >Mymensingh</option>
<option value=26 >Naogaon</option>
<option value=34 >Narail</option>
<option value=11 >Narayanganj</option>
<option value=19 >Narsingdi</option>
<option value=27 >Natore</option>
<option value=28 >Nawabganj</option>
<option value=21 >Netrokona</option>
<option value=62 >Nilphamari</option>
<option value=45 >Noakhali</option>
<option value=29 >Pabna</option>
<option value=63 >Panchagarh</option>
<option value=53 >Patuakhali</option>
<option value=54 >Pirojpur</option>
<option value=22 >Rajbari</option>
<option value=2 >Rajshahi</option>
<option value=41 >Rangamati</option>
<option value=7 >Rangpur</option>
<option value=20 >Shariatpur</option>
<option value=31 >Shatkhira</option>
<option value=17 >Sherpur</option>
<option value=30 >Sirajganj</option>
<option value=57 >Sunamgonj</option>
<option value=6 >Sylhet</option>
<option value=12 >Tangail</option>
<option value=64 >Thakurgaon</option>
</select>
</div>
</div>
                      
<div class="hr-dashed"></div>
<div class="form-group">
<label class="col-sm-2 control-label">Present Address<span style="color:red">*</span></label>
<div class="col-sm-10">
<textarea class="form-control" name="address" value="<?php echo $address;?>" required> </textarea>
</div>
</div>

<div class="hr-dashed"></div>
<div class="form-group">
<label class="col-sm-2 control-label">Message<span style="color:red">*</span></label>
<div class="col-sm-10">
<textarea class="form-control" name="message" value="<?php echo $message;?>" required> </textarea>
</div>
</div>



                      <div class="form-group">
                        <div class="col-sm-8 col-sm-offset-2 text-center">
                          <button class="btn btn-default" type="reset">Clear</button>
                          <button class="btn btn-primary" name="submit" type="submit">Submit</button>
                        </div>
                      </div>

                    </form>
      </div>
    </div>
  </div>
</div>

  <!-- Loading Scripts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" ></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap-select.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.dataTables.min.js"></script>
  <script src="js/dataTables.bootstrap.min.js"></script>
  <script src="js/Chart.min.js"></script>
  <script src="js/fileinput.js"></script>
  <script src="js/chartData.js"></script>
  <script src="js/main.js"></script>


<script>
  
  $(document).ready(function() {
    $(.editbtn).on('click', function(){
      $('#editmodal').modal('focus');
    })
  });

</script>


</body>
</html>
<?php } ?>


























