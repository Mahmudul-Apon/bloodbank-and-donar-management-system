<style>
	/*.ts-sidebar{background: linear-gradient(to bottom, #244363 0%, #3C5B77 100%);}*/
	.ts-sidebar{
		background:url(images/bg-01.jpg);

	}
	.ts-sidebar-menu .ts-label {color: black;font-size: 12px;}
	.ts-sidebar-menu li i {color: #FFFFFF;}
	.ts-sidebar-menu > .open > a {
    background: linear-gradient( #0066cc );
    transition: .9s;
}
.ts-sidebar-menu a:hover{
    text-decoration: none;
    color: #FFFFFF;
    /*background-color: #93C54B;*/
    transition: .5s;
    border: 1px solid #ddd;
    border-radius: 4px;
}
.ts-sidebar-menu a {
    

}
.ts-sidebar-menu > .open > a {
    background: border-box;
    border-left: 3px solid #37a6c4;
}
</style>



	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			
				<li><a href="#"><i class="fa fa-files-o"></i> Blood Group</a>
				<ul>
				<li><a href="add-bloodgroup.php">Add Blood Group</a></li>
				<li><a href="manage-bloodgroup.php">Manage Blood Group</a></li>
				</ul>
				</li>


				<li><a href="add-donor.php"><i class="fa fa-edit"></i> Add Donor</a></li>
				<li><a href="donor-list.php"><i class="fa fa-users"></i> Donor List</a></li>
				<li><a href=""><i class="fa fa-user"></i> Donor Area</a>
					<ul>
						<li><a href="donor-registration.php">Donor Registration</a></li>
						<li><a href="donor-login.php">Donor Login</a></li>
						<li><a href="donor-Profile.php">Donor Profile</a></li>
					</ul>

				</li>

				<li><a href="manage-conactusquery.php"><i class="fa fa-desktop""></i> Manage Conatctus Query</a></li>
				<li><a href="manage-pages.php"><i class="fa fa-files-o"></i> Manage Pages</a></li>
				<li><a href="update-contactinfo.php"><i class="fa fa-files-o"></i> Update Contact Info</a></li>
				<li><a href="change-password.php"><i class="fa fa-unlock-alt"></i> Change Password</a></li>


			</ul>
		</nav>