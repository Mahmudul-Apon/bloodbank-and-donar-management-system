<style>
	.brand{
		/*background: linear-gradient(to right, #244363 0%, #3C5B77 100%);*/
		background:url(images/bg-01.jpg);
		background-size: cover;

	}
	.brand a{
		font-size: 20px; padding-top:1%; color:#fff; padding-left: 20px;
	}
	.brand .ts-profile-nav .ts-account > a {
    width: 180px;
    background: border-box;
    font-family: Constantia;
	}
	.brand .ts-profile-nav li ul li a {
    padding: 5px 20px;
    font-size: 13px;
    /* background:url(images/bg-01.jpg);*/
     background-size: cover;
    
}
	.brand .ts-profile-nav li ul li a:hover {
    color: #FFFFFF;
    background: #068F8D;
}
</style>


<div class="brand clearfix">
	<a href="dashboard.php">BloodBank & Donor Management System </a>  
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav">
			
			<li class="ts-account">
				<a href="#"><img src="img/ts-avatar.jpg" class="ts-avatar hidden-side" alt=""> Account <i class="fa fa-angle-down hidden-side"></i></a>
				<ul>
					<li><a href="change-password.php">Change Password</a></li>
					<li><a href="logout.php">Logout</a></li>
				</ul>
			</li>
		</ul>
	</div>

