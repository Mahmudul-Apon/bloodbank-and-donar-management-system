<?php
	session_start();
	include 'configl.php';

	$update=false;
	$id="";
	$fullname="";
	$mobileno="";
	$emailid="";
	$password="";
	$donation="";
	$age="";
	$gender="";
	$bloodgroup="";
	$smoker="";
	$drug="";
	$ldate="";
	$weight="";
	$birth="";
	$district="";
	$address="";
	$message="";
	$status = "1";


	if(isset($_POST['add'])){
		$fullname=$_POST['fullname'];
		$emailid=$_POST['emailid'];
		$mobileno=$_POST['mobileno'];


		$query="INSERT INTO tbregister(fullname,emailid,mobileno,photo)VALUES(?,?,?,?)";
		$stmt=$conn->prepare($query);
		$stmt->bind_param("ssss",$fullname,$emailid,$mobileno,$upload);
		$stmt->execute();
		

		header('location:indexl.php');
		$_SESSION['response']="Successfully Inserted to the database!";
		$_SESSION['res_type']="success";
	}
	
	if(isset($_GET['delete'])){
		$id=$_GET['delete'];

		$query="DELETE FROM tbregister WHERE id=?";
		$stmt=$conn->prepare($query);
		$stmt->bind_param("i",$id);
		$stmt->execute();

		header('location:donor-Profile.php');
		$_SESSION['response']="Successfully Deleted!";
		$_SESSION['res_type']="danger";
	}
	if(isset($_GET['edit'])){
		$id=$_GET['edit'];

		$query="SELECT * FROM tbregister WHERE id=?";
		$stmt=$conn->prepare($query);
		$stmt->bind_param("i",$id);
		$stmt->execute();
		$result=$stmt->get_result();
		$row=$result->fetch_assoc();

		$id=$row['id'];
		$fullname=$row['fullname'];
		$mobileno=$row['mobileno'];
		$emailid=$row['emailid'];
		$password=$row['password'];
		$donation=$row['donation'];
		$age=$row['age'];
		$gender=$row['gender'];
		$bloodgroup=$row['bloodgroup'];
		$smoker=$row['smoker'];
		$drug=$row['drug'];
		$ldate=$row['ldate'];
		$weight=$row['weight'];
		$birth=$row['birth'];
		$district=$row['district'];
		$address=$row['address'];
		$message=$row['message'];
		$status = "1";

		$update=true;
	}
	if(isset($_POST['update'])){
		$id=$_POST['id'];
		$fullname=$_POST['fullname'];
		$mobileno=$_POST['mobileno'];
		$emailid=$_POST['emailid'];
		$password=$_POST['password'];
		$donation=$_POST['donation'];
		$age=$_POST['age'];
		$gender=$_POST['gender'];
		$bloodgroup=$_POST['bloodgroup'];
		$smoker=$_POST['smoker'];
		$drug=$_POST['drug'];
		$ldate=$_POST['ldate'];
		$weight=$_POST['weight'];
		$birth=$_POST['birth'];
		$district=$_POST['district'];
		$address=$_POST['address'];
		$message=$_POST['message'];
		$status = "1";



		$query="UPDATE tbregister SET fullname=?,mobileno=?,emailid=?,password=?, age=?, gender=?, bloodgroup=?, smoker=?, drug=?, ldate=?, weight=?, birth=?, district=?, address=?, message=?, donation=?, WHERE id=?";
		$stmt=$conn->prepare($query);
		$stmt->bind_param("sssssssssssssssssi",$fullname, $mobileno , $emailid , $password , $age , $gender , $bloodgroup , $smoker , $drug , $ldate , $weight , $birth , $district , $address , $message , $donation ,  $status );
		$stmt->execute();

		$_SESSION['response']="Updated Successfully!";
		$_SESSION['res_type']="primary";
		header('location:donor-Profile.php');
	}

	if(isset($_GET['details'])){
		$id=$_GET['details'];
		$query="SELECT * FROM tbregister WHERE id=?";
		$stmt=$conn->prepare($query);
		$stmt->bind_param("i",$id);
		$stmt->execute();
		$result=$stmt->get_result();
		$row=$result->fetch_assoc();


		$vid=$row['id'];
		$vfullname=$row['fullname'];
		$vmobileno=$row['mobileno'];
		$vemailid=$row['emailid'];
		$vpassword=$row['password'];
		$donation=$row['donation'];
		$vage=$row['age'];
		$vgender=$row['gender'];
		$vbloodgroup=$row['bloodgroup'];
		$vsmoker=$row['smoker'];
		$vdrug=$row['drug'];
		$vldate=$row['ldate'];
		$vweight=$row['weight'];
		$vbirth=$row['birth'];
		$vdistrict=$row['district'];
		$vaddress=$row['address'];
		$vmessage=$row['message'];
		
	}
?>