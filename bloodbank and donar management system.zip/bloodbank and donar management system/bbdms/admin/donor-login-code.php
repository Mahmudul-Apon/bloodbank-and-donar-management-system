<?php 

	session_start();

	  define('DB_SERVER', 'localhost');
	  define('DB_USERNAME', 'root');
	  define('DB_PASSWORD', '');
	  define('DB_DATABASE', 'bbdms');

  $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		
		$emailid = mysqli_real_escape_string($db,$_POST['emailid']);
        $password = mysqli_real_escape_string($db,$_POST['password']);

        $sql = "SELECT id FROM tbregister WHERE emailid = '$emailid' && password = '$password'";
		// $sql = "SELECT id FROM loginfo WHERE username = '$myusername' and password = '$mypassword'";

		$result = mysqli_query($db,$sql);
		$count = mysqli_num_rows($result);

		if ($count == 1) {
			$_SESSION['submit'] = $emailid;
			// echo "Login Successful!";
			header("location: loginp.php");
		}
		else{
			echo "Login Failed!";
		}
	}



 ?>