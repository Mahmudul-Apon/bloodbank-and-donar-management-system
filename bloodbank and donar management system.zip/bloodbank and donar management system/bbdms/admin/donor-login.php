<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
?>
<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>BBDMS| Donor Registration</title>

	<!-- Font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
	<link rel="stylesheet" href="css/style.css">
<style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}

.form-control {
        display: block;
    width: 30%;
    height: 38px;
    padding: 12px 16px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #3e3f3a;
    background-color: #ffffff;
    background-image: none;
    border: 1px solid #dfd7ca;
    border-radius: 4px;
}


.btn {
        border: none;
    font-size: 14px;
    line-height: 22px;
    font-weight: 500;
    text-transform: uppercase;
    padding: 6px 45px;
}

.page-title {
    padding-bottom: 15px;
    margin-bottom: 2px;
    border-bottom: 1px solid #f0f0f0;
}
p.p-1.m-0.font-ubuntu.text-black-50 {
    margin-bottom: 5px;
}
.panel {
    margin-top: 5px;
}

.panel-default .panel-heading, .panel-default .panel-title, .panel-default .panel-footer {
    text-align: left;
}

form.form-horizontal {
    padding: 40px 0px;
}





</style>
<script language="javascript">
function isNumberKey(evt)
      {
         
        var charCode = (evt.which) ? evt.which : event.keyCode
                
        if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode!=46)
           return false;

         return true;
      }
      </script>
</head>

<body>
	<?php include('includes/header.php');?>
	<div class="ts-main-content">
	<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12 text-center">
					
						<h2 class="page-title">Login</h2>
                    <p class="p-1 m-0 font-ubuntu text-black-50">Login and enjoy additional features</p>
                    <span class="font-ubuntu text-black-50">Create a new <a href="donor-registration.php">account</a></span>

						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-default">
									<!-- <div class="panel-heading">Basic Info</div>
<?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?> -->

<div class="panel-body text-center">
<form method="post" class="form-horizontal" enctype="multipart/form-data" action="donor-login-code.php">
<div class="form-group text-center">

<label class="col-sm-4 control-label">E-mail<span style="color:red"></span></label>
<input type="text" name="emailid" class="form-control" placeholder="Enter Email" required>

</div>

<div class="form-group">

<label class="col-sm-4 control-label">Password<span style="color:red"></span></label>
<input type="text" name="password" class="form-control" placeholder="Enter Password" required>

</div>


											<div class="form-group">
												<div class="col-sm-8 col-sm-offset-2 text-center">
													<button class="btn btn-warning" name="submit" type="submit">Login</button>
												</div>
											</div>

										</form>
									</div>
								</div>
							</div>
						</div>
						
					

					</div>
				</div>
				
			

			</div>
		</div>
	</div>

	<!-- Loading Scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
</body>
</html>
