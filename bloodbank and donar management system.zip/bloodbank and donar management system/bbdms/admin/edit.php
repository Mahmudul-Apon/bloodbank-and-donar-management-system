<?php
  include 'actionl.php';
?>

<!-- 
<?php
session_start();
error_reporting(0);
include('includes/config.php');
include 'action.php';
if(strlen($_SESSION['alogin'])==0)
  { 
header('location:index.php');
}
else{ 

if (isset($_POST['update'])) {
  $fullname = $_POST['fullname'];
  $mobileno = $_POST['mobileno'];
  $emailid = $_POST['emailid'];
  $password = $_POST['password'];
  $age = $_POST['age'];
  $gender = $_POST['gender'];
  $bloodgroup = $_POST['bloodgroup'];
  $smoker = $_POST['smoker'];
  $drug = $_POST['drug'];
  $ldate = $_POST['ldate'];
  $weight = $_POST['weight'];
  $birth = $_POST['birth'];
  $district = $_POST['district'];
  $address = $_POST['address'];
  $message = $_POST['message'];
  $donation = $_POST['donation'];
  $status = 1;

    $query="UPDATE tbregister SET fullname=?,mobileno=?,emailid=?,password=?, age=?, gender=?, bloodgroup=?, smoker=?, drug=?, ldate=?, weight=?, birth=?, district=?, address=?, message=?, donation=?, WHERE id=?";
    $stmt=$conn->prepare($query);
    $stmt->bind_param("ssssi",$fullname, $mobileno , $emailid , $password , $age , $gender , $bloodgroup , $smoker , $drug , $ldate , $weight , $birth , $district , $address , $message , $donation ,  $status );
    $stmt->execute();

    $_SESSION['response']="Updated Successfully!";
    $_SESSION['res_type']="primary";
    header('location:index.php');



$query = $dbh->prepare($sql);
$query->bindParam(':fullname',$fullname,PDO::PARAM_STR);
$query->bindParam(':mobileno',$mobileno,PDO::PARAM_STR);
$query->bindParam(':emailid',$emailid,PDO::PARAM_STR);
$query->bindParam(':password',$password,PDO::PARAM_STR);
$query->bindParam(':donation',$donation,PDO::PARAM_STR);
$query->bindParam(':age',$age,PDO::PARAM_STR);
$query->bindParam(':gender',$gender,PDO::PARAM_STR);
$query->bindParam(':bloodgroup',$bloodgroup,PDO::PARAM_STR);
$query->bindParam(':smoker',$smoker,PDO::PARAM_STR);
$query->bindParam(':drug',$drug,PDO::PARAM_STR);
$query->bindParam(':ldate',$ldate,PDO::PARAM_STR);
$query->bindParam(':weight',$weight,PDO::PARAM_STR);
$query->bindParam(':birth',$birth,PDO::PARAM_STR);
$query->bindParam(':district',$district,PDO::PARAM_STR);
$query->bindParam(':message',$message,PDO::PARAM_STR);
$query->bindParam(':status',$status,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$msg="Your info submitted successfully";
}
else 
{
$error="Something went wrong. Please try again";
}

}


  ?> -->
<!doctype html>
<html lang="en" class="no-js">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <meta name="theme-color" content="#3e454c">
  
  <title>BBDMS| Donor Registration</title>

  <!-- Font awesome -->
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <!-- Sandstone Bootstrap CSS -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- Bootstrap Datatables -->
  <link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
  <!-- Bootstrap social button library -->
  <link rel="stylesheet" href="css/bootstrap-social.css">
  <!-- Bootstrap select -->
  <link rel="stylesheet" href="css/bootstrap-select.css">
  <!-- Bootstrap file input -->
  <link rel="stylesheet" href="css/fileinput.min.css">
  <!-- Awesome Bootstrap checkbox -->
  <link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
  <!-- Admin Stye -->
  <link rel="stylesheet" href="css/style.css">
<style>
    .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}

.form-control {
    display: block;
    width: 100%;
    height: 41px;
    padding: 12px 16px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #3e3f3a;
    background-color: #ffffff;
    background-image: none;
    border: 1px solid #dfd7ca;
    border-radius: 4px;
}


.btn {
        border: none;
    font-size: 14px;
    line-height: 22px;
    font-weight: 500;
    text-transform: uppercase;
    padding: 6px 45px;
}

.page-title {
    padding-bottom: 15px;
    margin-bottom: 2px;
    border-bottom: 1px solid #f0f0f0;
}
p.p-1.m-0.font-ubuntu.text-black-50 {
    margin-bottom: 5px;
}
.panel {
    margin-top: 5px;
}

.panel-default .panel-heading, .panel-default .panel-title, .panel-default .panel-footer {
    text-align: left;
}
.panel-default>.panel-heading {
    background-color: #2AAB9D;
    border-color: #dfd7ca;
}
.panel-default .panel-heading, .panel-default .panel-title, .panel-default .panel-footer {
  color: #FFFFFF;
}
</style>
<script language="javascript">
function isNumberKey(evt)
      {
         
        var charCode = (evt.which) ? evt.which : event.keyCode
                
        if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode!=46)
           return false;

         return true;
      }
      </script>
</head>

<body>
  <?php include('includes/header.php');?>
  <div class="ts-main-content">
  <?php include('includes/leftbar.php');?>
    <div class="content-wrapper">
      <div class="container-fluid">

        <div class="row">
          <div class="col-md-12 text-center">
          
            <h2 class="page-title">Update Info</h2>
                    <p class="p-1 m-0 font-ubuntu text-black-50">Register and enjoy additional features</p>
                    <span class="font-ubuntu text-black-50">I already have <a href="donor-login.php">Login</a></span>

            <div class="row">
              <div class="col-md-12">
                <div class="panel panel-default">
                  <div class="panel-heading">Basic Info</div>
<?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
        else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>

<div class="panel-body">
<form action="actionl.php" method="POST" class="form-horizontal" enctype="multipart/form-data" >
<input type="hidden" name="id" value="<?= $id; ?>">
<div class="form-group">
<label class="col-sm-2 control-label">Full Name<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="fullname" class="form-control" value="<?= $fullname;?>" required>
</div>
<label class="col-sm-2 control-label">Mobile No<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="mobileno" onKeyPress="return isNumberKey(event)"  maxlength="10" class="form-control" value="<?= $mobileno;?>" required>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Email id </label>
<div class="col-sm-4">
<input type="email" name="emailid" class="form-control" value="<?= $emailid;?>">
</div>

<label class="col-sm-2 control-label">Password </label>
<div class="col-sm-4">
<input type="password" name="password" class="form-control" value="<?= $password;?>">
</div>

</div>



<div class="form-group">
<label class="col-sm-2 control-label">How many times donation ?<span style="color:red">*</span></label>
<div class="col-sm-4">
<select name="donation" class="form-control" value="<?= $gender;?>" required>
<option value="">Select</option>
<option value="">Not once</option>
<option value="Male">1</option>
<option value="Male">2</option>
<option value="Male">3</option>
<option value="Male">4</option>
<option value="Male">5</option>
<option value="Male">6</option>
<option value="Male">7</option>
<option value="Male">8</option>
<option value="Male">9</option>
<option value="Male">10</option>
</select>
</div>
<label class="col-sm-2 control-label">Age<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="age" class="form-control" value="<?= $age;?>" required>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Gender <span style="color:red">*</span></label>
<div class="col-sm-4">
<select name="gender" class="form-control" value="<?= $gender;?>" required>
<option value="">Select</option>
<option value="Male">Male</option>
<option value="Female">Female</option>
<option value="Female">Others</option>
</select>
</div>
<label class="col-sm-2 control-label">Blood Group<span style="color:red">*</span></label>
<div class="col-sm-4">


<select name="bloodgroup" class="form-control" value="<?= $bloodgroup;?>" required>
<option value="">Select</option>
<?php $sql = "SELECT * from  tblbloodgroup ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{       ?>  
<option value="<?php echo htmlentities($result->BloodGroup);?>"><?php echo htmlentities($result->BloodGroup);?></option>
<?php }} ?>
</select>

</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Smoker? <span style="color:red">*</span></label>
<div class="col-sm-4">
<select name="smoker" class="form-control" value="<?= $smoker;?>" required>
<option value="">Select</option>
<option value="Male">No</option>
<option value="Female">Yes</option>
</select>
</div>

<label class="col-sm-2 control-label">Drug Accidted? <span style="color:red">*</span></label>
<div class="col-sm-4">
<select name="drug" class="form-control" value="<?= $drug;?>" required>
<option value="">Select</option>
<option value="Male">No</option>
<option value="Female">Yes</option>
</select>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Last Donation Date </label>
<div class="col-sm-4">
<input type="date" name="ldate" class="form-control" value="<?= $ldate;?>" >
</div>

<label class="col-sm-2 control-label">Weight<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="weight" class="form-control" value="<?= $weight;?>" required>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Date of Birth </label>
<div class="col-sm-4">
<input type="date" name="birth" class="form-control" value="<?= $birth;?>">
</div>

<label class="col-sm-2 control-label">Living District <span style="color:red">*</span></label>
<div class="col-sm-4">
<select name="district" class="form-control" value="<?= $district;?>" required>
<option value="0">Select one...</option><option value=32 >Bagerhat</option>
<option value=40 >Bandarban</option>
<option value=50 >Barguna</option>
<option value=5 >Barisal</option>
<option value=51 >Bhola</option>
<option value=24 >Bogra</option>
<option value=48 >Brahmanbaria</option>
<option value=49 >Chandpur</option>
<option value=4 >Chittagong</option>
<option value=37 >Chuadanga</option>
<option value=47 >Comilla</option>
<option value=43 >Cox's Bazar</option>
<option value=1 >Dhaka</option>
<option value=58 >Dinajpur</option>
<option value=23 >Faridpur</option>
<option value=44 >Feni</option>
<option value=59 >Gaibandha</option>
<option value=9 >Gazipur</option>
<option value=16 >Gopalganj</option>
<option value=56 >Habiganj</option>
<option value=25 >Jaipurhat</option>
<option value=14 >Jamalpur</option>
<option value=33 >Jessore</option>
<option value=52 >Jhalokati</option>
<option value=36 >Jhenaidah</option>
<option value=42 >Khagrachari</option>
<option value=3 >Khulna</option>
<option value=18 >Kishoreganj</option>
<option value=60 >Kurigram</option>
<option value=38 >Kushtia</option>
<option value=46 >Lakshmipur</option>
<option value=61 >Lalmonirhat</option>
<option value=13 >Madaripur</option>
<option value=35 >Magura</option>
<option value=8 >Manikgonj</option>
<option value=55 >Maulvi Bazar</option>
<option value=39 >Meherpur</option>
<option value=15 >Munshiganj</option>
<option value=10 >Mymensingh</option>
<option value=26 >Naogaon</option>
<option value=34 >Narail</option>
<option value=11 >Narayanganj</option>
<option value=19 >Narsingdi</option>
<option value=27 >Natore</option>
<option value=28 >Nawabganj</option>
<option value=21 >Netrokona</option>
<option value=62 >Nilphamari</option>
<option value=45 >Noakhali</option>
<option value=29 >Pabna</option>
<option value=63 >Panchagarh</option>
<option value=53 >Patuakhali</option>
<option value=54 >Pirojpur</option>
<option value=22 >Rajbari</option>
<option value=2 >Rajshahi</option>
<option value=41 >Rangamati</option>
<option value=7 >Rangpur</option>
<option value=20 >Shariatpur</option>
<option value=31 >Shatkhira</option>
<option value=17 >Sherpur</option>
<option value=30 >Sirajganj</option>
<option value=57 >Sunamgonj</option>
<option value=6 >Sylhet</option>
<option value=12 >Tangail</option>
<option value=64 >Thakurgaon</option>
</select>
</div>
</div>
                      
<div class="hr-dashed"></div>
<div class="form-group">
<label class="col-sm-2 control-label">Present Address<span style="color:red">*</span></label>
<div class="col-sm-10">
<textarea class="form-control" name="address" value="<?= $address;?>" required> </textarea>
</div>
</div>

<div class="hr-dashed"></div>
<div class="form-group">
<label class="col-sm-2 control-label">Message<span style="color:red">*</span></label>
<div class="col-sm-10">
<textarea class="form-control" name="message" value="<?= $message;?>" required> </textarea>
</div>
</div>



            <div class="form-group">
            <?php if ($update == true) { ?>
           <!--  <a href="donor-Profile.php"><input type="submit" name="update" class="btn btn-success btn-block" value="Update Record"></a> -->

            <a href="donor-Profile.php" type="submit" name="update" class="btn btn-primary editbtn p-2">Update Record</a>

            <?php } else { ?>
            <a href="donor-Profile.php"><input type="submit" name="add" class="btn btn-primary btn-block" value="Add Record"></a>
            <?php } ?>
          </div>

                    </form>
                  
                  </div>
                </div>
              </div>
            </div>
            
          

          </div>
        </div>
        
      

      </div>
    </div>
  </div>

  <!-- Loading Scripts -->
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap-select.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.dataTables.min.js"></script>
  <script src="js/dataTables.bootstrap.min.js"></script>
  <script src="js/Chart.min.js"></script>
  <script src="js/fileinput.js"></script>
  <script src="js/chartData.js"></script>
  <script src="js/main.js"></script>
</body>
</html>
<?php } ?>